import tkinter as tk
from tkinter import filedialog
from tkinter import *
from tkinter import messagebox
import cv2
from PIL import ImageTk, Image
import numpy
import numpy as np
#load the trained model to animal class
from keras.models import load_model
from keras.preprocessing import image
from tensorflow.keras.utils import img_to_array


model = load_model('model3_animal (1).h5', compile=False)
model.compile(
    loss='categorical_crossentropy', 
    optimizer='adam', 
    metrics=['accuracy']
)

#initialise GUI
top=tk.Tk()
top.geometry('1000x800')

top.title('Sea Animal Classification with Neural Networks')
top.configure(background='#CDCDCD')
label=Label(top,background='#CDCDCD', font=('arial',15,'bold'))
sign_image = Label(top)
def classify(file_path):
   global label_packed
   image = Image.open(file_path)
   image = image.resize((40,40))

   image=img_to_array(image)
   image=image.astype('float32')
   image=image/255
   image=np.expand_dims(image,axis=0)
   result=(model.predict(image).argmax())
   classes=['','Bạch Tuộc','Cá', 'Cá Heo','Cá Mập', 'Cá Ngựa', 'Cá Voi', 'Cua', 'Rái Cá', 'Sao Biển','Tôm Biển']
  
   sign = classes[result]
   print(sign)
   label.configure(background='#1fa0cf',foreground='#09044d', text=sign,font=('arial',20,'bold'))

def show_classify_button(file_path):
   classify_b=Button(top,text="Classify Image",command=lambda: classify(file_path),padx=10,pady=10)
   classify_b.configure(background='#364156', foreground='white',font=('arial',15,'bold'))
   classify_b.place(relx=0.8,rely=0.3)
def upload_image():
    try:
       file_path=filedialog.askopenfilename()
       uploaded=Image.open(file_path)
       uploaded.thumbnail(((top.winfo_width()/2.25),(top.winfo_height()/2.25)))
       im=ImageTk.PhotoImage(uploaded)
       sign_image.configure(image=im)
       sign_image.image=im
       label.configure(text='')
       show_classify_button(file_path)
    except:
       pass
upload=Button(top,text="Upload an image",command=upload_image,padx=20,pady=10)
upload.configure(background='#364156', foreground='white',font=('arial',15,'bold'))
upload.pack(side=BOTTOM,pady=50)
sign_image.pack(side=BOTTOM,expand=True)
label.pack(side=BOTTOM,expand=True)
heading = Label(top, text="CHECK SEA ANIMAL ",pady=20, font=('arial',25,'bold'))
heading.configure(background='#CDCDCD',foreground='#364156')
heading.pack()
top.mainloop()